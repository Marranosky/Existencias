namespace ApiExistenciasSimuladas.Models;

public class ConsultaExistenciaResponse
{
    public string NumMaterial { get; set; }
    public decimal Existencia { get; set; }
    public string Mensaje { get; set; }
}