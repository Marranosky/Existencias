namespace ApiExistenciasSimuladas.Models;

public class ConsultaExistenciaRequest
{
    public string Material { get; set; }
    public string Centro { get; set; }
    public string Almacen { get; set; }
}